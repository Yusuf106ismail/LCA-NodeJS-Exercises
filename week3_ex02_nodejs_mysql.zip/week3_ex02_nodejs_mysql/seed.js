const pool = require('./config/db');

async function seedDatabase() {
  try {
    await pool.execute('DELETE FROM products');
    await pool.execute('DELETE FROM employees');

    const products = [
      ['Biltong 250g', 89.99, 'Snacks'],
      ['Rooibos Tea 80s', 45.50, 'Beverages'],
      ['Mrs H.S. Ball\'s Chutney 470g', 38.00, 'Condiments'],
      ['Braai Salt Premium', 29.95, 'Spices'],
      ['Amarula Cream Liqueur 750ml', 189.00, 'Beverages']
    ];

    for (const prod of products) {
      await pool.execute(
        'INSERT INTO products (name, price, category) VALUES (?, ?, ?)',
        prod
      );
    }

    const employees = [
      ['Sipho Nkosi', 'sipho.nkosi@techvibe.co.za', 'Engineering'],
      ['Thandiwe Dlamini', 'thandiwe.d@techvibe.co.za', 'Human Resources'],
      ['Pieter van der Merwe', 'pieter.vdm@techvibe.co.za', 'Finance'],
      ['Keisha Naidoo', 'keisha.n@techvibe.co.za', 'Marketing'],
      ['Lerato Molefe', 'lerato.m@techvibe.co.za', 'Operations']
    ];

    for (const emp of employees) {
      await pool.execute(
        'INSERT INTO employees (name, email, department) VALUES (?, ?, ?)',
        emp
      );
    }

    console.log('Database seeded successfully!');
  } catch (error) {
    console.error('Error seeding database:', error.message);
  } finally {
    await pool.end();
  }
}

seedDatabase();

