const pool = require('./config/db');
const productModel = require('./models/productModel');
const employeeModel = require('./models/employeeModel');

async function runTests() {
  console.log('--- STARTING CRUD TESTS ---\n');

  try {
    console.log('--- 1. Get All Products ---');
    const initialProducts = await productModel.getAllProducts();
    console.log(initialProducts);

    console.log('\n--- 2. Add New Product ---');
    const addProdResult = await productModel.addProduct('Boerewors 500g', 65.00, 'Meat');
    console.log('Insert Result:', addProdResult);
    const newProductId = addProdResult.insertId;

    console.log(`\n--- 3. Get Product By ID (${newProductId}) ---`);
    const newProduct = await productModel.getProductById(newProductId);
    console.log(newProduct);

    console.log(`\n--- 4. Update Product (${newProductId}) ---`);
    await productModel.updateProduct(newProductId, 'Traditional Boerewors 500g', 69.90, 'Meat');
    const updatedProd = await productModel.getProductById(newProductId);
    console.log('Updated Record:', updatedProd);

    console.log(`\n--- 5. Delete Product (${newProductId}) ---`);
    await productModel.deleteProduct(newProductId);
    const postDeleteProd = await productModel.getProductById(newProductId);
    console.log('Fetch after delete:', postDeleteProd);

    console.log('\n--- 6. Get All Employees ---');
    const allEmployees = await employeeModel.getAllEmployees();
    console.log(allEmployees);

    console.log('\n--- 7. Add New Employee ---');
    const addEmpResult = await employeeModel.addEmployee('Kagiso Rabada', 'kagiso.r@techvibe.co.za', 'Logistics');
    console.log('Insert Result:', addEmpResult);
    const newEmpId = addEmpResult.insertId;

    console.log(`\n--- 8. Get Employee By ID (${newEmpId}) ---`);
    const newEmp = await employeeModel.getEmployeeById(newEmpId);
    console.log(newEmp);

    console.log(`\n--- 9. Delete Employee (${newEmpId}) ---`);
    await employeeModel.deleteEmployee(newEmpId);
    const postDeleteEmp = await employeeModel.getEmployeeById(newEmpId);
    console.log('Fetch after delete:', postDeleteEmp);

  } catch (error) {
    console.error('An error occurred during verification:', error.message);
  } finally {
    await pool.end();
    console.log('\n--- TESTS COMPLETED ---');
  }
}

runTests();

