const pool = require('../config/db');

async function getAllProducts() {
  try {
    const [rows] = await pool.execute('SELECT * FROM products');
    return rows;
  } catch (error) {
    console.error('Error fetching products:', error.message);
    throw error;
  }
}

async function getProductById(id) {
  try {
    const [rows] = await pool.execute('SELECT * FROM products WHERE id = ?', [id]);
    if (rows.length === 0) {
      return { message: `Product with ID ${id} not found.` };
    }
    return rows[0];
  } catch (error) {
    console.error(`Error fetching product ${id}:`, error.message);
    throw error;
  }
}

async function addProduct(name, price, category) {
  try {
    const [result] = await pool.execute(
      'INSERT INTO products (name, price, category) VALUES (?, ?, ?)',
      [name, price, category]
    );
    return result;
  } catch (error) {
    console.error('Error adding product:', error.message);
    throw error;
  }
}

async function updateProduct(id, name, price, category) {
  try {
    const [result] = await pool.execute(
      'UPDATE products SET name = ?, price = ?, category = ? WHERE id = ?',
      [name, price, category, id]
    );
    return result;
  } catch (error) {
    console.error(`Error updating product ${id}:`, error.message);
    throw error;
  }
}

async function deleteProduct(id) {
  try {
    const [result] = await pool.execute('DELETE FROM products WHERE id = ?', [id]);
    return result;
  } catch (error) {
    console.error(`Error deleting product ${id}:`, error.message);
    throw error;
  }
}

module.exports = {
  getAllProducts,
  getProductById,
  addProduct,
  updateProduct,
  deleteProduct
};

