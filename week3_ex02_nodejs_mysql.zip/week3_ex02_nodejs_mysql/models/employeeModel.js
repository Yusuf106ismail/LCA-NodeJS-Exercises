const pool = require('../config/db');

async function getAllEmployees() {
  try {
    const [rows] = await pool.execute('SELECT * FROM employees');
    return rows;
  } catch (error) {
    console.error('Error fetching employees:', error.message);
    throw error;
  }
}

async function getEmployeeById(id) {
  try {
    const [rows] = await pool.execute('SELECT * FROM employees WHERE id = ?', [id]);
    if (rows.length === 0) {
      return { message: `Employee with ID ${id} not found.` };
    }
    return rows[0];
  } catch (error) {
    console.error(`Error fetching employee ${id}:`, error.message);
    throw error;
  }
}

async function addEmployee(name, email, department) {
  try {
    const [result] = await pool.execute(
      'INSERT INTO employees (name, email, department) VALUES (?, ?, ?)',
      [name, email, department]
    );
    return result;
  } catch (error) {
    console.error('Error adding employee:', error.message);
    throw error;
  }
}

async function deleteEmployee(id) {
  try {
    const [result] = await pool.execute('DELETE FROM employees WHERE id = ?', [id]);
    return result;
  } catch (error) {
    console.error(`Error deleting employee ${id}:`, error.message);
    throw error;
  }
}

module.exports = {
  getAllEmployees,
  getEmployeeById,
  addEmployee,
  deleteEmployee
};

