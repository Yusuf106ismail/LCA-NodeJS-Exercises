const pool = require('../config/db');

async function getAllProducts() {
  const [rows] = await pool.execute('SELECT * FROM products');
  return rows;
}

async function getProductById(id) {
  const [rows] = await pool.execute('SELECT * FROM products WHERE id = ?', [id]);
  return rows[0];
}

async function createProduct(name, price, category) {
  const [result] = await pool.execute(
    'INSERT INTO products (name, price, category) VALUES (?, ?, ?)',
    [name, price, category]
  );
  return result;
}

async function updateProduct(id, name, price, category) {
  const [result] = await pool.execute(
    'UPDATE products SET name = ?, price = ?, category = ? WHERE id = ?',
    [name, price, category, id]
  );
  return result;
}

async function deleteProduct(id) {
  const [result] = await pool.execute('DELETE FROM products WHERE id = ?', [id]);
  return result;
}

module.exports = {
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct
};

