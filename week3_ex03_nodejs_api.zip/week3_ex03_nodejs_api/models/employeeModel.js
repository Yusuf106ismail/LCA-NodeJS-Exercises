const pool = require('../config/db');

async function getAllEmployees() {
  const [rows] = await pool.execute('SELECT * FROM employees');
  return rows;
}

async function getEmployeeById(id) {
  const [rows] = await pool.execute('SELECT * FROM employees WHERE id = ?', [id]);
  return rows[0];
}

async function createEmployee(name, email, department_id) {
  const [result] = await pool.execute(
    'INSERT INTO employees (name, email, department_id) VALUES (?, ?, ?)',
    [name, email, department_id]
  );
  return result;
}

async function updateEmployee(id, name, email, department_id) {
  const [result] = await pool.execute(
    'UPDATE employees SET name = ?, email = ?, department_id = ? WHERE id = ?',
    [name, email, department_id, id]
  );
  return result;
}

async function deleteEmployee(id) {
  const [result] = await pool.execute('DELETE FROM employees WHERE id = ?', [id]);
  return result;
}

async function getEmployeesByLocation(location) {
  const query = `
    SELECT e.id, e.name, e.email, d.department_name, d.location
    FROM employees e
    INNER JOIN departments d ON e.department_id = d.id
    WHERE d.location = ?
  `;
  const [rows] = await pool.execute(query, [location]);
  return rows;
}

module.exports = {
  getAllEmployees,
  getEmployeeById,
  createEmployee,
  updateEmployee,
  deleteEmployee,
  getEmployeesByLocation
};

