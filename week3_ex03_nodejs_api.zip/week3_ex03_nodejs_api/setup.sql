CREATE DATABASE IF NOT EXISTS techvibe_db;
USE techvibe_db;

DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS products;

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  category VARCHAR(100) NOT NULL
);

CREATE TABLE departments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  department_name VARCHAR(100) NOT NULL,
  location VARCHAR(100) NOT NULL
);

CREATE TABLE employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  department_id INT,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

INSERT INTO departments (id, department_name, location) VALUES
(1, 'Engineering', 'Cape Town'),
(2, 'Human Resources', 'Johannesburg'),
(3, 'Finance', 'Cape Town');

INSERT INTO products (id, name, price, category) VALUES
(1, 'Biltong 250g', 89.99, 'Snacks'),
(2, 'Rooibos Tea 80s', 45.50, 'Beverages');

INSERT INTO employees (id, name, email, department_id) VALUES
(1, 'Sipho Nkosi', 'sipho.nkosi@techvibe.co.za', 1),
(2, 'Thandiwe Dlamini', 'thandiwe.d@techvibe.co.za', 2),
(3, 'Pieter van der Merwe', 'pieter.vdm@techvibe.co.za', 1);

