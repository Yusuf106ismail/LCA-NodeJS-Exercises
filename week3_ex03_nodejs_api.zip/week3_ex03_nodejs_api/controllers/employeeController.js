const employeeModel = require('../models/employeeModel');

async function getAllEmployees(req, res) {
  try {
    const employees = await employeeModel.getAllEmployees();
    res.status(200).json(employees);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function getEmployeeById(req, res) {
  try {
    const employee = await employeeModel.getEmployeeById(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    res.status(200).json(employee);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function createEmployee(req, res) {
  try {
    const { name, email, department_id } = req.body;
    const result = await employeeModel.createEmployee(name, email, department_id);
    res.status(201).json({ id: result.insertId, name, email, department_id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function updateEmployee(req, res) {
  try {
    const { name, email, department_id } = req.body;
    const result = await employeeModel.updateEmployee(req.params.id, name, email, department_id);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    res.status(200).json({ message: 'Employee updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function deleteEmployee(req, res) {
  try {
    const result = await employeeModel.deleteEmployee(req.params.id);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    res.status(200).json({ message: 'Employee deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function getEmployeesByLocation(req, res) {
  try {
    const employees = await employeeModel.getEmployeesByLocation(req.params.location);
    res.status(200).json(employees);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

module.exports = {
  getAllEmployees,
  getEmployeeById,
  createEmployee,
  updateEmployee,
  deleteEmployee,
  getEmployeesByLocation
};

