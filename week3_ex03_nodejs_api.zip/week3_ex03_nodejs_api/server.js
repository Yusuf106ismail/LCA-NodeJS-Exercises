const express = require('express');
require('dotenv').config();

const productRoutes = require('./routes/productRoutes');
const employeeRoutes = require('./routes/employeeRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.use('/products', productRoutes);
app.use('/employees', employeeRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

