const express = require('express');
const router = express.Router();

// GET all employees
router.get('/', (req, res) => {
  res.json({ message: 'GET all employees' });
});

// POST new employee
router.post('/', (req, res) => {
  res.json({ message: 'POST employee', data: req.body });
});

// PUT update employee
router.put('/:id', (req, res) => {
  res.json({ message: `PUT employee ${req.params.id}`, data: req.body });
});

// PATCH update employee
router.patch('/:id', (req, res) => {
  res.json({ message: `PATCH employee ${req.params.id}`, data: req.body });
});

// DELETE employee
router.delete('/:id', (req, res) => {
  res.json({ message: `DELETE employee ${req.params.id}` });
});

module.exports = router;
