const express = require('express');
const router = express.Router();

// GET all products
router.get('/', (req, res) => {
  res.json({ message: 'GET all products' });
});

// POST new product
router.post('/', (req, res) => {
  res.json({ message: 'POST product', data: req.body });
});

// PUT update product
router.put('/:id', (req, res) => {
  res.json({ message: `PUT product ${req.params.id}`, data: req.body });
});

// PATCH update product
router.patch('/:id', (req, res) => {
  res.json({ message: `PATCH product ${req.params.id}`, data: req.body });
});

// DELETE product
router.delete('/:id', (req, res) => {
  res.json({ message: `DELETE product ${req.params.id}` });
});

module.exports = router;
